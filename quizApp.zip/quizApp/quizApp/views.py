from django.shortcuts import render, redirect, get_list_or_404, get_object_or_404
from .models import QuizSubtype, Response, QuizType
from random import shuffle, choice
from copy import copy

from django.http import HttpResponse
from django.shortcuts import render,redirect
from . import models
from . import forms

# Create your views here.

def some_view(request):
    if request.method == 'POST':
        form = SomeForm(request.POST)
        if form.is_valid():
            picked = form.cleaned_data.get('picked')
            # do something with your results
    else:
        form = SomeForm

    return render_to_response('some_template.html', {'form':form },
        context_instance=RequestContext(request))