from django import forms


class QuizzForm(forms.Form):
    question = forms.CharField()
    answers = forms.MultipleChoiceField()
    explantaion = forms.CharField()

class SomeForm(forms.Form):
    CHOICES = (('a','a'),
               ('b','b'),
               ('c','c'),
               ('d','d'),)
    picked = forms.MultipleChoiceField(choices=CHOICES, widget=forms.CheckboxSelectMultiple())